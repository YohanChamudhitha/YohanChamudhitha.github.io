import 'dart:html';

import 'package:flutter/material.dart';
import 'package:yohanchamudhithacv/cv.dart';



void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Yohan_Chamudhitha_Curriculum_Vitae',
      theme: ThemeData(
        primarySwatch: Colors.green,
      ),
      home: cv() ,
      debugShowCheckedModeBanner: false,
    );
  }
}