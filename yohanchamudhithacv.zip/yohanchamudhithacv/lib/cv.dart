import 'dart:ui';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:percent_indicator/percent_indicator.dart';


class cv extends StatelessWidget {
  const cv({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    print(MediaQuery.of(context).size.width);
    print(MediaQuery.of(context).size.height);
    var _screenSize = MediaQuery.of(context).size;
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
            image: DecorationImage(
                image: AssetImage("assets/images/06.jpg"),
                fit: BoxFit.fill
            )
        ),
        child: ClipRRect(
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 10,sigmaY: 10),
            child: Row(
              children: [
                Container(
                  margin: EdgeInsets.only(
                      left: _screenSize.width / 50,
                      right: _screenSize.width / 55,
                      top: _screenSize.height / 25,
                      bottom: _screenSize.height / 25),
                  width: _screenSize.width / 4,
                  height: _screenSize.height / 1.1,
                  decoration: BoxDecoration(
                    color: Color(0xffffb100),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey.withOpacity(1),
                        spreadRadius: 5,
                        blurRadius: 7,
                        offset: Offset(0, 3), // changes position of shadow
                      ),
                    ],
                  ),
                  child: Stack(
                    children: [
                      Container(
                        width: _screenSize.width / 4,
                        height: _screenSize.height / 4,
                        color: Color(0xfffbc252),
                      ),
                      Positioned(
                        bottom: 0,
                        child: Container(
                            width: _screenSize.width / 4,
                            height: _screenSize.height / 4.55 * 3,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.only(
                                bottomRight: Radius.circular(30),
                                bottomLeft: Radius.circular(30),
                              ),
                              color: Color(0xff000000),
                            ),
                            child: Column(
                              children: [
                                Align(
                                    alignment: Alignment.centerLeft,
                                    child: Container(
                                      padding: EdgeInsets.only(
                                          left: _screenSize.width / 50,
                                          top: _screenSize.height / 3.9),
                                      child: Text(
                                        "YOHAN",
                                        style: GoogleFonts.montserrat(
                                            textStyle: TextStyle(
                                          color: Colors.white,
                                          fontSize: _screenSize.aspectRatio * 15,
                                        )),
                                      ),
                                    )),
                                Align(
                                    alignment: Alignment.centerLeft,
                                    child: Container(
                                      padding: EdgeInsets.only(
                                          left: _screenSize.width / 50),
                                      child: Text(
                                        "CHAMUDHITHA",
                                        style: TextStyle(
                                            color: Color(0xfffbc252),
                                            fontSize: _screenSize.aspectRatio * 17,
                                        fontWeight: FontWeight.bold),
                                      ),
                                    )),
                                Align(
                                    alignment: Alignment.centerLeft,
                                    child: Container(
                                      padding: EdgeInsets.only(
                                          left: _screenSize.width / 50),
                                      child: Text(
                                        "JUNIOR FRONT - END DEVELOPER",
                                        style: TextStyle(
                                            color: Colors.white,
                                            fontSize: _screenSize.aspectRatio * 6),
                                      ),
                                    )),
                                Divider(
                                  thickness: _screenSize.width / 1000,
                                  color: Colors.white54,
                                  indent: 30,
                                  endIndent: 50,
                                ),
                                Align(
                                    alignment: Alignment.centerLeft,
                                    child: Container(
                                      padding: EdgeInsets.only(
                                          left: _screenSize.width / 50,
                                          right: _screenSize.width / 50),
                                      child: Text(
                                        "I am Information & Communication Technology diplomat looking for a opportunity to improve skills and to gain new skills.I have short experience in front-end developing, networking and hardware that I would like to improve.I have a friendly personality and love teamwork. ",
                                        style: TextStyle(
                                            color: Colors.white54,
                                            fontSize: _screenSize.aspectRatio * 6),
                                      ),
                                    )),
                              ],
                            )),
                      ),
                      Positioned(
                          right: 0,
                          top: 0,
                          left: 0,
                          child: CircleAvatar(
                              backgroundColor: Colors.white,
                              radius: _screenSize.width / 8,
                              child: CircleAvatar(
                                backgroundColor: Colors.transparent,
                                backgroundImage:
                                    AssetImage("assets/images/08.jpg"),
                                radius: _screenSize.width / 9,
                              )))
                    ],
                  ),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Align(
                      alignment: Alignment.topLeft,
                      child: Container(
                          margin: EdgeInsets.only(
                              top: _screenSize.height / 22,
                              left: _screenSize.width / 100),
                          width: _screenSize.width / 6,
                          height: _screenSize.height / 25,
                          decoration: BoxDecoration(
                            borderRadius:
                                BorderRadius.only(topRight: Radius.circular(45)),
                            color: Color(0xff000000),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.grey.withOpacity(1),
                                spreadRadius: 5,
                                blurRadius: 7,
                                offset: Offset(0, 3), // changes position of shadow
                              ),
                            ],
                          ),
                          child: Align(
                            alignment: Alignment.centerLeft,
                            child: Container(
                                width: _screenSize.width / 6.1,
                                height: _screenSize.height / 25,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.only(
                                    topRight: Radius.circular(50),
                                  ),
                                  color: Color(0xfffbc252),
                                ),
                                child: Align(
                                  alignment: Alignment.center,
                                  child: Text(
                                    "CONTACT INFO",
                                    style: GoogleFonts.montserrat(
                                        textStyle: TextStyle(
                                            color: Colors.black,
                                            fontSize: _screenSize.aspectRatio * 6,
                                            fontWeight: FontWeight.bold)),
                                  ),
                                )),
                          )),
                    ),
                    Row(
                      children: [
                        Container(
                          margin: EdgeInsets.only(
                              left: _screenSize.width / 50,
                              top: _screenSize.height / 25),
                          width: _screenSize.width / 30,
                          height: _screenSize.height / 15,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              color: Color(0x46fbc252)),
                          child: Icon(Icons.call),
                        ),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              margin: EdgeInsets.only(
                                  left: _screenSize.width / 50,
                                  top: _screenSize.height / 30),
                              child: Text(
                                "Phone",
                                style: GoogleFonts.montserrat(
                                    textStyle: TextStyle(
                                        color: Colors.black,
                                        fontSize: _screenSize.aspectRatio * 7,
                                        fontWeight: FontWeight.bold)),
                              ),
                            ),
                            Container(
                              margin: EdgeInsets.only(left: _screenSize.width / 50),
                              child: Text(
                                "+94766759164",
                                style: GoogleFonts.montserrat(
                                    textStyle: TextStyle(
                                  color: Colors.black,
                                  fontSize: _screenSize.aspectRatio * 7,
                                )),
                              ),
                            )
                          ],
                        ),
                      ],
                    ),
                    Row(
                      children: [
                        Container(
                          margin: EdgeInsets.only(
                              left: _screenSize.width / 50,
                              top: _screenSize.height / 25),
                          width: _screenSize.width / 30,
                          height: _screenSize.height / 15,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              color: Color(0x46fbc252)),
                          child: Icon(Icons.mail_rounded),
                        ),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              margin: EdgeInsets.only(
                                  left: _screenSize.width / 50,
                                  top: _screenSize.height / 30),
                              child: Text(
                                "E-Mail",
                                style: GoogleFonts.montserrat(
                                    textStyle: TextStyle(
                                        color: Colors.black,
                                        fontSize: _screenSize.aspectRatio * 7,
                                        fontWeight: FontWeight.bold)),
                              ),
                            ),
                            Container(
                              margin: EdgeInsets.only(left: _screenSize.width / 50),
                              child: Text(
                                "ychamu2@gmail.com",
                                style: GoogleFonts.montserrat(
                                    textStyle: TextStyle(
                                  color: Colors.black,
                                  fontSize: _screenSize.aspectRatio * 7,
                                )),
                              ),
                            )
                          ],
                        ),
                      ],
                    ),
                    Row(
                      children: [
                        Container(
                          margin: EdgeInsets.only(
                              left: _screenSize.width / 50,
                              top: _screenSize.height / 25),
                          width: _screenSize.width / 30,
                          height: _screenSize.height / 15,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              color: Color(0x46fbc252)),
                          child: Icon(Icons.location_on_rounded),
                        ),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              margin: EdgeInsets.only(
                                  left: _screenSize.width / 50,
                                  top: _screenSize.height / 30),
                              child: Text(
                                "Address",
                                style: GoogleFonts.montserrat(
                                    textStyle: TextStyle(
                                        color: Colors.black,
                                        fontSize: _screenSize.aspectRatio * 7,
                                        fontWeight: FontWeight.bold)),
                              ),
                            ),
                            Container(
                              margin: EdgeInsets.only(left: _screenSize.width / 50),
                              child: Text(
                                "112B, Labuwelgoda, Matugama Road, \nWalagedara, "
                                "Western Province, Sri Lanka.",
                                style: GoogleFonts.montserrat(
                                    textStyle: TextStyle(
                                  color: Colors.black,
                                  fontSize: _screenSize.aspectRatio * 7,
                                )),
                              ),
                            )
                          ],
                        ),
                      ],
                    ),
                    Align(
                      alignment: Alignment.topLeft,
                      child: Container(
                          margin: EdgeInsets.only(
                              top: _screenSize.height / 18,
                              left: _screenSize.width / 100),
                          width: _screenSize.width / 6,
                          height: _screenSize.height / 25,
                          decoration: BoxDecoration(
                            borderRadius:
                                BorderRadius.only(topRight: Radius.circular(45)),
                            color: Color(0xff000000),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.grey.withOpacity(1),
                                spreadRadius: 5,
                                blurRadius: 7,
                                offset: Offset(0, 3), // changes position of shadow
                              ),
                            ],
                          ),
                          child: Align(
                            alignment: Alignment.centerLeft,
                            child: Container(
                                width: _screenSize.width / 6.1,
                                height: _screenSize.height / 25,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.only(
                                    topRight: Radius.circular(50),
                                  ),
                                  color: Color(0xfffbc252),
                                ),
                                child: Align(
                                  alignment: Alignment.center,
                                  child: Text(
                                    "MY SKILLS",
                                    style: GoogleFonts.montserrat(
                                        textStyle: TextStyle(
                                            color: Colors.black,
                                            fontSize: _screenSize.aspectRatio * 6,
                                            fontWeight: FontWeight.bold)),
                                  ),
                                )),
                          )),
                    ),
                    Container(
                      margin: EdgeInsets.only(
                          left: _screenSize.width / 150,
                          top: _screenSize.height / 50,
                          bottom: _screenSize.height / 25),
                      width: _screenSize.width / 3,
                      height: _screenSize.height / 2.456,
                      child: ListView(
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Container(
                                    margin: EdgeInsets.only(
                                        left: _screenSize.width / 150,
                                        top: _screenSize.height / 30),
                                    child: Text(
                                      "Flutter",
                                      style: GoogleFonts.montserrat(
                                          textStyle: TextStyle(
                                              color: Colors.black,
                                              fontSize: _screenSize.aspectRatio * 7,
                                              fontWeight: FontWeight.bold)),
                                    ),
                                  ),
                                  Padding(
                                    padding: EdgeInsets.only(
                                        left: _screenSize.width / 39.5,
                                        top: _screenSize.height / 30),
                                    child: LinearPercentIndicator(
                                        width: _screenSize.width / 4.3,
                                        animation: true,
                                        lineHeight: 10.0,
                                        animationDuration: 3000,
                                        percent: 0.2,
                                        center: Text(
                                          "20%",
                                          style: GoogleFonts.montserrat(
                                              textStyle: TextStyle(
                                                  color: Colors.black,
                                                  fontSize:
                                                      _screenSize.aspectRatio * 4,
                                                  fontWeight: FontWeight.bold)),
                                        ),
                                        barRadius: Radius.circular(10),
                                        progressColor: Color(0xfffbc252)),
                                  ),
                                ],
                              ),
                              Row(
                                children: [
                                  Row(
                                    children: [
                                      Container(
                                        margin: EdgeInsets.only(
                                            left: _screenSize.width / 150,
                                            top: _screenSize.height / 50),
                                        child: Text(
                                          "HTML",
                                          style: GoogleFonts.montserrat(
                                              textStyle: TextStyle(
                                                  color: Colors.black,
                                                  fontSize:
                                                      _screenSize.aspectRatio * 7,
                                                  fontWeight: FontWeight.bold)),
                                        ),
                                      ),
                                    ],
                                  ),
                                  Padding(
                                    padding: EdgeInsets.only(
                                        left: _screenSize.width / 32.8,
                                        top: _screenSize.height / 50),
                                    child: LinearPercentIndicator(
                                        width: _screenSize.width / 4.3,
                                        animation: true,
                                        lineHeight: 10.0,
                                        animationDuration: 3000,
                                        percent: 0.8,
                                        center: Text(
                                          "80%",
                                          style: GoogleFonts.montserrat(
                                              textStyle: TextStyle(
                                                  color: Colors.black,
                                                  fontSize:
                                                      _screenSize.aspectRatio * 4,
                                                  fontWeight: FontWeight.bold)),
                                        ),
                                        barRadius: Radius.circular(10),
                                        progressColor: Color(0xfffbc252)),
                                  ),
                                ],
                              ),
                              Row(
                                children: [
                                  Row(
                                    children: [
                                      Container(
                                        margin: EdgeInsets.only(
                                            left: _screenSize.width / 150,
                                            top: _screenSize.height / 50),
                                        child: Text(
                                          "CSS",
                                          style: GoogleFonts.montserrat(
                                              textStyle: TextStyle(
                                                  color: Colors.black,
                                                  fontSize:
                                                      _screenSize.aspectRatio * 7,
                                                  fontWeight: FontWeight.bold)),
                                        ),
                                      ),
                                    ],
                                  ),
                                  Padding(
                                    padding: EdgeInsets.only(
                                        left: _screenSize.width / 24,
                                        top: _screenSize.height / 50),
                                    child: LinearPercentIndicator(
                                        width: _screenSize.width / 4.3,
                                        animation: true,
                                        lineHeight: 10.0,
                                        animationDuration: 3000,
                                        percent: 0.6,
                                        center: Text(
                                          "60%",
                                          style: GoogleFonts.montserrat(
                                              textStyle: TextStyle(
                                                  color: Colors.black,
                                                  fontSize:
                                                      _screenSize.aspectRatio * 4,
                                                  fontWeight: FontWeight.bold)),
                                        ),
                                        barRadius: Radius.circular(10),
                                        progressColor: Color(0xfffbc252)),
                                  ),
                                ],
                              ),
                              Row(
                                children: [
                                  Row(
                                    children: [
                                      Container(
                                        margin: EdgeInsets.only(
                                            left: _screenSize.width / 150,
                                            top: _screenSize.height / 50),
                                        child: Text(
                                          "JAVA",
                                          style: GoogleFonts.montserrat(
                                              textStyle: TextStyle(
                                                  color: Colors.black,
                                                  fontSize:
                                                      _screenSize.aspectRatio * 7,
                                                  fontWeight: FontWeight.bold)),
                                        ),
                                      ),
                                    ],
                                  ),
                                  Padding(
                                    padding: EdgeInsets.only(
                                        left: _screenSize.width / 29,
                                        top: _screenSize.height / 50),
                                    child: LinearPercentIndicator(
                                        width: _screenSize.width / 4.3,
                                        animation: true,
                                        lineHeight: 10.0,
                                        animationDuration: 3000,
                                        percent: 0.4,
                                        center: Text(
                                          "40%",
                                          style: GoogleFonts.montserrat(
                                              textStyle: TextStyle(
                                                  color: Colors.black,
                                                  fontSize:
                                                      _screenSize.aspectRatio * 4,
                                                  fontWeight: FontWeight.bold)),
                                        ),
                                        barRadius: Radius.circular(10),
                                        progressColor: Color(0xfffbc252)),
                                  ),
                                ],
                              ),
                              Row(
                                children: [
                                  Row(
                                    children: [
                                      Container(
                                        margin: EdgeInsets.only(
                                            left: _screenSize.width / 150,
                                            top: _screenSize.height / 50),
                                        child: Text(
                                          "SQL",
                                          style: GoogleFonts.montserrat(
                                              textStyle: TextStyle(
                                                  color: Colors.black,
                                                  fontSize:
                                                      _screenSize.aspectRatio * 7,
                                                  fontWeight: FontWeight.bold)),
                                        ),
                                      ),
                                    ],
                                  ),
                                  Padding(
                                    padding: EdgeInsets.only(
                                        left: _screenSize.width / 24,
                                        top: _screenSize.height / 50),
                                    child: LinearPercentIndicator(
                                        width: _screenSize.width / 4.3,
                                        animation: true,
                                        lineHeight: 10.0,
                                        animationDuration: 3000,
                                        percent: 0.5,
                                        center: Text(
                                          "50%",
                                          style: GoogleFonts.montserrat(
                                              textStyle: TextStyle(
                                                  color: Colors.black,
                                                  fontSize:
                                                      _screenSize.aspectRatio * 4,
                                                  fontWeight: FontWeight.bold)),
                                        ),
                                        barRadius: Radius.circular(10),
                                        progressColor: Color(0xfffbc252)),
                                  ),
                                ],
                              ),
                              Row(
                                children: [
                                  Row(
                                    children: [
                                      Container(
                                        margin: EdgeInsets.only(
                                            left: _screenSize.width / 150,
                                            top: _screenSize.height / 50),
                                        child: Text(
                                          "PLSQL",
                                          style: GoogleFonts.montserrat(
                                              textStyle: TextStyle(
                                                  color: Colors.black,
                                                  fontSize:
                                                      _screenSize.aspectRatio * 7,
                                                  fontWeight: FontWeight.bold)),
                                        ),
                                      ),
                                    ],
                                  ),
                                  Padding(
                                    padding: EdgeInsets.only(
                                        left: _screenSize.width / 36,
                                        top: _screenSize.height / 50),
                                    child: LinearPercentIndicator(
                                        width: _screenSize.width / 4.3,
                                        animation: true,
                                        lineHeight: 10.0,
                                        animationDuration: 3000,
                                        percent: 0.4,
                                        center: Text(
                                          "40%",
                                          style: GoogleFonts.montserrat(
                                              textStyle: TextStyle(
                                                  color: Colors.black,
                                                  fontSize:
                                                      _screenSize.aspectRatio * 4,
                                                  fontWeight: FontWeight.bold)),
                                        ),
                                        barRadius: Radius.circular(10),
                                        progressColor: Color(0xfffbc252)),
                                  ),
                                ],
                              ),
                              Row(
                                children: [
                                  Row(
                                    children: [
                                      Container(
                                        margin: EdgeInsets.only(
                                            left: _screenSize.width / 150,
                                            top: _screenSize.height / 50),
                                        child: Text(
                                          "Photoshop",
                                          style: GoogleFonts.montserrat(
                                              textStyle: TextStyle(
                                                  color: Colors.black,
                                                  fontSize:
                                                      _screenSize.aspectRatio * 7,
                                                  fontWeight: FontWeight.bold)),
                                        ),
                                      ),
                                    ],
                                  ),
                                  Padding(
                                    padding: EdgeInsets.only(
                                        left: _screenSize.width / 250,
                                        top: _screenSize.height / 50),
                                    child: LinearPercentIndicator(
                                        width: _screenSize.width / 4.3,
                                        animation: true,
                                        lineHeight: 10.0,
                                        animationDuration: 3000,
                                        percent: 0.3,
                                        center: Text(
                                          "30%",
                                          style: GoogleFonts.montserrat(
                                              textStyle: TextStyle(
                                                  color: Colors.black,
                                                  fontSize:
                                                      _screenSize.aspectRatio * 4,
                                                  fontWeight: FontWeight.bold)),
                                        ),
                                        barRadius: Radius.circular(10),
                                        progressColor: Color(0xfffbc252)),
                                  ),
                                ],
                              ),
                              Row(
                                children: [
                                  Row(
                                    children: [
                                      Container(
                                        margin: EdgeInsets.only(
                                            left: _screenSize.width / 150,
                                            top: _screenSize.height / 50),
                                        child: Text(
                                          "Illustrator",
                                          style: GoogleFonts.montserrat(
                                              textStyle: TextStyle(
                                                  color: Colors.black,
                                                  fontSize:
                                                      _screenSize.aspectRatio * 7,
                                                  fontWeight: FontWeight.bold)),
                                        ),
                                      ),
                                    ],
                                  ),
                                  Padding(
                                    padding: EdgeInsets.only(
                                        left: _screenSize.width / 100,
                                        top: _screenSize.height / 50),
                                    child: LinearPercentIndicator(
                                        width: _screenSize.width / 4.3,
                                        animation: true,
                                        lineHeight: 10.0,
                                        animationDuration: 3000,
                                        percent: 0.3,
                                        center: Text(
                                          "30%",
                                          style: GoogleFonts.montserrat(
                                              textStyle: TextStyle(
                                                  color: Colors.black,
                                                  fontSize:
                                                      _screenSize.aspectRatio * 4,
                                                  fontWeight: FontWeight.bold)),
                                        ),
                                        barRadius: Radius.circular(10),
                                        progressColor: Color(0xfffbc252)),
                                  ),
                                ],
                              ),
                              Row(
                                children: [
                                  Row(
                                    children: [
                                      Container(
                                        margin: EdgeInsets.only(
                                            left: _screenSize.width / 150,
                                            top: _screenSize.height / 50),
                                        child: Text(
                                          "PHP",
                                          style: GoogleFonts.montserrat(
                                              textStyle: TextStyle(
                                                  color: Colors.black,
                                                  fontSize:
                                                      _screenSize.aspectRatio * 7,
                                                  fontWeight: FontWeight.bold)),
                                        ),
                                      ),
                                    ],
                                  ),
                                  Padding(
                                    padding: EdgeInsets.only(
                                        left: _screenSize.width / 25,
                                        top: _screenSize.height / 50),
                                    child: LinearPercentIndicator(
                                        width: _screenSize.width / 4.3,
                                        animation: true,
                                        lineHeight: 10.0,
                                        animationDuration: 3000,
                                        percent: 0.4,
                                        center: Text(
                                          "20%",
                                          style: GoogleFonts.montserrat(
                                              textStyle: TextStyle(
                                                  color: Colors.black,
                                                  fontSize:
                                                      _screenSize.aspectRatio * 4,
                                                  fontWeight: FontWeight.bold)),
                                        ),
                                        barRadius: Radius.circular(10),
                                        progressColor: Color(0xfffbc252)),
                                  ),
                                ],
                              ),
                              Row(
                                children: [
                                  Row(
                                    children: [
                                      Container(
                                        margin: EdgeInsets.only(
                                            left: _screenSize.width / 150,
                                            top: _screenSize.height / 50),
                                        child: Text(
                                          "Arduino",
                                          style: GoogleFonts.montserrat(
                                              textStyle: TextStyle(
                                                  color: Colors.black,
                                                  fontSize:
                                                      _screenSize.aspectRatio * 7,
                                                  fontWeight: FontWeight.bold)),
                                        ),
                                      ),
                                    ],
                                  ),
                                  Padding(
                                    padding: EdgeInsets.only(
                                        left: _screenSize.width / 50,
                                        top: _screenSize.height / 50),
                                    child: LinearPercentIndicator(
                                        width: _screenSize.width / 4.3,
                                        animation: true,
                                        lineHeight: 10.0,
                                        animationDuration: 3000,
                                        percent: 0.2,
                                        center: Text(
                                          "20%",
                                          style: GoogleFonts.montserrat(
                                              textStyle: TextStyle(
                                                  color: Colors.black,
                                                  fontSize:
                                                      _screenSize.aspectRatio * 4,
                                                  fontWeight: FontWeight.bold)),
                                        ),
                                        barRadius: Radius.circular(10),
                                        progressColor: Color(0xfffbc252)),
                                  ),
                                ],
                              ),
                            ],
                          )
                        ],
                      ),
                    )
                  ],
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Align(
                      alignment: Alignment.topLeft,
                      child: Container(
                          margin: EdgeInsets.only(
                              top: _screenSize.height / 22,
                              left: _screenSize.width / 150),
                          width: _screenSize.width / 6,
                          height: _screenSize.height / 25,
                          decoration: BoxDecoration(
                            borderRadius:
                                BorderRadius.only(topRight: Radius.circular(45)),
                            color: Color(0xff000000),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.grey.withOpacity(1),
                                spreadRadius: 5,
                                blurRadius: 7,
                                offset: Offset(0, 3), // changes position of shadow
                              ),
                            ],
                          ),
                          child: Align(
                            alignment: Alignment.centerLeft,
                            child: Container(
                                width: _screenSize.width / 6.1,
                                height: _screenSize.height / 25,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.only(
                                    topRight: Radius.circular(50),
                                  ),
                                  color: Color(0xfffbc252),
                                ),
                                child: Align(
                                  alignment: Alignment.center,
                                  child: Text(
                                    "EDUCATION",
                                    style: GoogleFonts.montserrat(
                                        textStyle: TextStyle(
                                            color: Colors.black,
                                            fontSize: _screenSize.aspectRatio * 6,
                                            fontWeight: FontWeight.bold)),
                                  ),
                                )),
                          )),
                    ),
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Container(
                          margin: EdgeInsets.only(
                              left: _screenSize.width / 50,
                              top: _screenSize.height / 25),
                          child: Text(
                            "GCE O/L Examination\n(2016)",
                            style: GoogleFonts.montserrat(
                                textStyle: TextStyle(
                                    color: Colors.black,
                                    fontSize: _screenSize.aspectRatio * 7,
                                    fontWeight: FontWeight.bold)),
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.only(
                              left: _screenSize.width / 50,
                              top: _screenSize.height / 25),
                          width: _screenSize.width / 10,
                          height: _screenSize.height / 20,
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                                primary: Color(0x46fbc252),
                                onPrimary: Colors.black,
                                onSurface: Color(0xfffbc252),
                                shadowColor: Colors.transparent),
                            child: Text("Click Here",style: GoogleFonts.azeretMono(textStyle: TextStyle(color: Colors.black,fontSize:
                            _screenSize.aspectRatio*6,fontWeight: FontWeight.bold)),),
                            onPressed: () {
                              showDialog(
                                context: context,
                                builder: (BuildContext context) => Dialog(
                                  backgroundColor: Colors.white.withOpacity(0.6),
                                  child: Container(
                                      padding: EdgeInsets.only(
                                          left: _screenSize.width / 20,
                                          right: _screenSize.width / 10,
                                          bottom: _screenSize.height / 10),
                                      width: _screenSize.width / 3,
                                      height: _screenSize.height / 1.2,
                                      child: Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceEvenly,
                                        children: [
                                          Align(
                                            alignment: Alignment.topCenter,
                                            child: Container(
                                                margin: EdgeInsets.only(
                                                    top: _screenSize.height / 22,
                                                    left: _screenSize.width / 50),
                                                width: _screenSize.width / 6,
                                                height: _screenSize.height / 25,
                                                decoration: BoxDecoration(
                                                  borderRadius: BorderRadius.only(
                                                      topRight: Radius.circular(45)),
                                                  color: Color(0xff000000),
                                                  boxShadow: [
                                                    BoxShadow(
                                                      color:
                                                          Colors.grey.withOpacity(1),
                                                      spreadRadius: 5,
                                                      blurRadius: 7,
                                                      offset: Offset(0,
                                                          3), // changes position of shadow
                                                    ),
                                                  ],
                                                ),
                                                child: Align(
                                                  alignment: Alignment.centerLeft,
                                                  child: Container(
                                                      width: _screenSize.width / 6.2,
                                                      height: _screenSize.height / 25,
                                                      decoration: BoxDecoration(
                                                        borderRadius:
                                                        BorderRadius.only(
                                                          topRight:
                                                          Radius.circular(50),
                                                        ),
                                                        color: Color(0xfffbc252),
                                                      ),
                                                      child: Align(
                                                        alignment: Alignment.center,
                                                        child: Text(
                                                          "GCE A/L Examination\n(2019)",
                                                          style: GoogleFonts.montserrat(
                                                              textStyle: TextStyle(
                                                                  color: Colors.black,
                                                                  fontSize: _screenSize
                                                                      .aspectRatio *
                                                                      5,
                                                                  fontWeight:
                                                                  FontWeight
                                                                      .bold)),
                                                        ),
                                                      )),
                                                )),
                                          ),
                                          Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: [
                                              Text(
                                                "Buddhism",
                                                style: GoogleFonts.montserrat(
                                                    textStyle: TextStyle(
                                                        color: Colors.black,
                                                        fontSize:
                                                            _screenSize.aspectRatio *
                                                                7,
                                                        fontWeight: FontWeight.bold)),
                                              ),
                                              Spacer(),
                                              Text(
                                                "A",
                                                style: GoogleFonts.montserrat(
                                                    textStyle: TextStyle(
                                                        color: Colors.black,
                                                        fontSize:
                                                            _screenSize.aspectRatio *
                                                                7,
                                                        fontWeight: FontWeight.bold)),
                                              ),
                                            ],
                                          ),
                                          Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: [
                                              Text(
                                                "English",
                                                style: GoogleFonts.montserrat(
                                                    textStyle: TextStyle(
                                                        color: Colors.black,
                                                        fontSize:
                                                            _screenSize.aspectRatio *
                                                                7,
                                                        fontWeight: FontWeight.bold)),
                                              ),
                                              Spacer(),
                                              Text(
                                                "A",
                                                style: GoogleFonts.montserrat(
                                                    textStyle: TextStyle(
                                                        color: Colors.black,
                                                        fontSize:
                                                            _screenSize.aspectRatio *
                                                                7,
                                                        fontWeight: FontWeight.bold)),
                                              ),
                                            ],
                                          ),
                                          Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: [
                                              Text(
                                                "Sinhala",
                                                style: GoogleFonts.montserrat(
                                                    textStyle: TextStyle(
                                                        color: Colors.black,
                                                        fontSize:
                                                            _screenSize.aspectRatio *
                                                                7,
                                                        fontWeight: FontWeight.bold)),
                                              ),
                                              Spacer(),
                                              Text(
                                                "A",
                                                style: GoogleFonts.montserrat(
                                                    textStyle: TextStyle(
                                                        color: Colors.black,
                                                        fontSize:
                                                            _screenSize.aspectRatio *
                                                                7,
                                                        fontWeight: FontWeight.bold)),
                                              ),
                                            ],
                                          ),
                                          Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: [
                                              Text(
                                                "Mathematics",
                                                style: GoogleFonts.montserrat(
                                                    textStyle: TextStyle(
                                                        color: Colors.black,
                                                        fontSize:
                                                            _screenSize.aspectRatio *
                                                                7,
                                                        fontWeight: FontWeight.bold)),
                                              ),
                                              Spacer(),
                                              Text(
                                                "B",
                                                style: GoogleFonts.montserrat(
                                                    textStyle: TextStyle(
                                                        color: Colors.black,
                                                        fontSize:
                                                            _screenSize.aspectRatio *
                                                                7,
                                                        fontWeight: FontWeight.bold)),
                                              ),
                                            ],
                                          ),
                                          Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: [
                                              Text(
                                                "Science",
                                                style: GoogleFonts.montserrat(
                                                    textStyle: TextStyle(
                                                        color: Colors.black,
                                                        fontSize:
                                                            _screenSize.aspectRatio *
                                                                7,
                                                        fontWeight: FontWeight.bold)),
                                              ),
                                              Spacer(),
                                              Text(
                                                "A",
                                                style: GoogleFonts.montserrat(
                                                    textStyle: TextStyle(
                                                        color: Colors.black,
                                                        fontSize:
                                                            _screenSize.aspectRatio *
                                                                7,
                                                        fontWeight: FontWeight.bold)),
                                              ),
                                            ],
                                          ),
                                          Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: [
                                              Text(
                                                "History",
                                                style: GoogleFonts.montserrat(
                                                    textStyle: TextStyle(
                                                        color: Colors.black,
                                                        fontSize:
                                                            _screenSize.aspectRatio *
                                                                7,
                                                        fontWeight: FontWeight.bold)),
                                              ),
                                              Spacer(),
                                              Text(
                                                "A",
                                                style: GoogleFonts.montserrat(
                                                    textStyle: TextStyle(
                                                        color: Colors.black,
                                                        fontSize:
                                                            _screenSize.aspectRatio *
                                                                7,
                                                        fontWeight: FontWeight.bold)),
                                              ),
                                            ],
                                          ),
                                          Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: [
                                              Text(
                                                "Information & \nCommunication Technology",
                                                style: GoogleFonts.montserrat(
                                                    textStyle: TextStyle(
                                                        color: Colors.black,
                                                        fontSize:
                                                            _screenSize.aspectRatio *
                                                                7,
                                                        fontWeight: FontWeight.bold)),
                                              ),
                                              Spacer(),
                                              Text(
                                                "A",
                                                style: GoogleFonts.montserrat(
                                                    textStyle: TextStyle(
                                                        color: Colors.black,
                                                        fontSize:
                                                            _screenSize.aspectRatio *
                                                                7,
                                                        fontWeight: FontWeight.bold)),
                                              ),
                                            ],
                                          ),
                                          Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: [
                                              Text(
                                                "Accounting & \nBusiness Studies",
                                                style: GoogleFonts.montserrat(
                                                    textStyle: TextStyle(
                                                        color: Colors.black,
                                                        fontSize:
                                                            _screenSize.aspectRatio *
                                                                7,
                                                        fontWeight: FontWeight.bold)),
                                              ),
                                              Spacer(),
                                              Text(
                                                "A",
                                                style: GoogleFonts.montserrat(
                                                    textStyle: TextStyle(
                                                        color: Colors.black,
                                                        fontSize:
                                                            _screenSize.aspectRatio *
                                                                7,
                                                        fontWeight: FontWeight.bold)),
                                              ),
                                            ],
                                          ),
                                          Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: [
                                              Text(
                                                "Art",
                                                style: GoogleFonts.montserrat(
                                                    textStyle: TextStyle(
                                                        color: Colors.black,
                                                        fontSize:
                                                            _screenSize.aspectRatio *
                                                                7,
                                                        fontWeight: FontWeight.bold)),
                                              ),
                                              Spacer(),
                                              Text(
                                                "A",
                                                style: GoogleFonts.montserrat(
                                                    textStyle: TextStyle(
                                                        color: Colors.black,
                                                        fontSize:
                                                            _screenSize.aspectRatio *
                                                                7,
                                                        fontWeight: FontWeight.bold)),
                                              ),
                                            ],
                                          ),
                                        ],
                                      )),
                                ),
                              );
                            },
                          ),
                        )
                      ],
                    ),
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Container(
                          margin: EdgeInsets.only(
                              left: _screenSize.width / 50,
                              top: _screenSize.height / 50),
                          child: Text(
                            "GCE A/L Examination\n(2016)",
                            style: GoogleFonts.montserrat(
                                textStyle: TextStyle(
                                    color: Colors.black,
                                    fontSize: _screenSize.aspectRatio * 7,
                                    fontWeight: FontWeight.bold)),
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.only(
                              left: _screenSize.width / 50,
                              top: _screenSize.height / 50),
                          width: _screenSize.width / 10,
                          height: _screenSize.height / 20,
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                                primary: Color(0x46fbc252),
                                onPrimary: Colors.black,
                                onSurface: Color(0xfffbc252),
                                shadowColor: Colors.transparent),
                            child: Text("Click Here",style: GoogleFonts.azeretMono(textStyle: TextStyle(color: Colors.black,fontSize:
                            _screenSize.aspectRatio*6,fontWeight: FontWeight.bold)),),
                            onPressed: () {
                              showDialog(
                                context: context,
                                builder: (BuildContext context) => Dialog(
                                  backgroundColor: Colors.white.withOpacity(0.6),
                                  child: Container(
                                      padding: EdgeInsets.only(
                                          left: _screenSize.width / 20,
                                          right: _screenSize.width / 30,
                                          bottom: _screenSize.height / 10),
                                      width: _screenSize.width / 3,
                                      height: _screenSize.height / 2,
                                      child: Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceEvenly,
                                        children: [
                                          Align(
                                            alignment: Alignment.topCenter,
                                            child: Container(
                                                margin: EdgeInsets.only(
                                                    top: _screenSize.height / 22,
                                                    left: _screenSize.width / 150),
                                                width: _screenSize.width / 6,
                                                height: _screenSize.height / 25,
                                                decoration: BoxDecoration(
                                                  borderRadius: BorderRadius.only(
                                                      topRight: Radius.circular(45)),
                                                  color: Color(0xff000000),
                                                  boxShadow: [
                                                    BoxShadow(
                                                      color:
                                                          Colors.grey.withOpacity(1),
                                                      spreadRadius: 5,
                                                      blurRadius: 7,
                                                      offset: Offset(0,
                                                          3), // changes position of shadow
                                                    ),
                                                  ],
                                                ),
                                                child: Align(
                                                  alignment: Alignment.centerLeft,
                                                  child: Container(
                                                      width: _screenSize.width / 6.1,
                                                      height: _screenSize.height / 25,
                                                      decoration: BoxDecoration(
                                                        borderRadius:
                                                            BorderRadius.only(
                                                          topRight:
                                                              Radius.circular(50),
                                                        ),
                                                        color: Color(0xfffbc252),
                                                      ),
                                                      child: Align(
                                                        alignment: Alignment.center,
                                                        child: Text(
                                                          "GCE A/L Examination\n(2019)",
                                                          style: GoogleFonts.montserrat(
                                                              textStyle: TextStyle(
                                                                  color: Colors.black,
                                                                  fontSize: _screenSize
                                                                          .aspectRatio *
                                                                      5,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .bold)),
                                                        ),
                                                      )),
                                                )),
                                          ),
                                          Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: [
                                              Text(
                                                "Information & \nCommunication Technology",
                                                style: GoogleFonts.montserrat(
                                                    textStyle: TextStyle(
                                                        color: Colors.black,
                                                        fontSize:
                                                            _screenSize.aspectRatio *
                                                                7,
                                                        fontWeight: FontWeight.bold)),
                                              ),
                                              Spacer(),
                                              Text(
                                                "S",
                                                style: GoogleFonts.montserrat(
                                                    textStyle: TextStyle(
                                                        color: Colors.black,
                                                        fontSize:
                                                            _screenSize.aspectRatio *
                                                                7,
                                                        fontWeight: FontWeight.bold)),
                                              ),
                                            ],
                                          ),
                                          Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: [
                                              Text(
                                                "Science For Technology",
                                                style: GoogleFonts.montserrat(
                                                    textStyle: TextStyle(
                                                        color: Colors.black,
                                                        fontSize:
                                                            _screenSize.aspectRatio *
                                                                7,
                                                        fontWeight: FontWeight.bold)),
                                              ),
                                              Spacer(),
                                              Text(
                                                "S",
                                                style: GoogleFonts.montserrat(
                                                    textStyle: TextStyle(
                                                        color: Colors.black,
                                                        fontSize:
                                                            _screenSize.aspectRatio *
                                                                7,
                                                        fontWeight: FontWeight.bold)),
                                              ),
                                            ],
                                          ),
                                          Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: [
                                              Text(
                                                "Engineering Technology",
                                                style: GoogleFonts.montserrat(
                                                    textStyle: TextStyle(
                                                        color: Colors.black,
                                                        fontSize:
                                                            _screenSize.aspectRatio *
                                                                7,
                                                        fontWeight: FontWeight.bold)),
                                              ),
                                              Spacer(),
                                              Text(
                                                "Absent",
                                                style: GoogleFonts.montserrat(
                                                    textStyle: TextStyle(
                                                        color: Colors.black,
                                                        fontSize:
                                                            _screenSize.aspectRatio *
                                                                7,
                                                        fontWeight: FontWeight.bold)),
                                              ),
                                            ],
                                          ),
                                          Row(
                                            mainAxisAlignment:
                                            MainAxisAlignment.start,
                                            children: [
                                              Text(
                                                "English",
                                                style: GoogleFonts.montserrat(
                                                    textStyle: TextStyle(
                                                        color: Colors.black,
                                                        fontSize:
                                                        _screenSize.aspectRatio *
                                                            7,
                                                        fontWeight: FontWeight.bold)),
                                              ),
                                              Spacer(),
                                              Text(
                                                "C",
                                                style: GoogleFonts.montserrat(
                                                    textStyle: TextStyle(
                                                        color: Colors.black,
                                                        fontSize:
                                                        _screenSize.aspectRatio *
                                                            7,
                                                        fontWeight: FontWeight.bold)),
                                              ),
                                            ],
                                          ),
                                        ],
                                      )),
                                ),
                              );
                            },
                          ),
                        )
                      ],
                    ),
                    Container(
                      margin: EdgeInsets.only(
                          right: _screenSize.width/50,
                          left: _screenSize.width / 50,
                          top: _screenSize.height / 50),
                      child: Text(
    "Computer Hardware Technician \nNVQ Level - 04 (2017)",
                        style: GoogleFonts.montserrat(
                            textStyle: TextStyle(
                                color: Colors.black,
                                fontSize: _screenSize.aspectRatio * 7,
                                fontWeight: FontWeight.bold)),
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.only(
                          right: _screenSize.width/50,
                          left: _screenSize.width / 50,
                          top: _screenSize.height / 50),
                      child: Text(
                        "Information & Communication Technology \nNVQ Level - 05 Diploma (2022)",
                        style: GoogleFonts.montserrat(
                            textStyle: TextStyle(
                                color: Colors.black,
                                fontSize: _screenSize.aspectRatio * 7,
                                fontWeight: FontWeight.bold)),
                      ),
                    ),
                    Align(
                      alignment: Alignment.topLeft,
                      child: Container(
                          margin: EdgeInsets.only(
                              top: _screenSize.height / 15,
                              left: _screenSize.width / 150),
                          width: _screenSize.width / 6,
                          height: _screenSize.height / 25,
                          decoration: BoxDecoration(
                            borderRadius:
                            BorderRadius.only(topRight: Radius.circular(45)),
                            color: Color(0xff000000),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.grey.withOpacity(1),
                                spreadRadius: 5,
                                blurRadius: 7,
                                offset: Offset(0, 3), // changes position of shadow
                              ),
                            ],
                          ),
                          child: Align(
                            alignment: Alignment.centerLeft,
                            child: Container(
                                width: _screenSize.width / 6.1,
                                height: _screenSize.height / 25,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.only(
                                    topRight: Radius.circular(50),
                                  ),
                                  color: Color(0xfffbc252),
                                ),
                                child: Align(
                                  alignment: Alignment.center,
                                  child: Text(
                                    "EXPERIENCE",
                                    style: GoogleFonts.montserrat(
                                        textStyle: TextStyle(
                                            color: Colors.black,
                                            fontSize: _screenSize.aspectRatio * 6,
                                            fontWeight: FontWeight.bold),),
                                  ),
                                )),
                          )),
                    ),
                    Container(
                      margin: EdgeInsets.only(
                          right: _screenSize.width/50,
                          left: _screenSize.width / 50,
                          top: _screenSize.height / 25),
                      child: Row(
                        children: [
                          Text("Trainee Full Stack Developer ",style: GoogleFonts.montserrat(
                            textStyle: TextStyle(
                                color: Colors.black,
                                fontSize: _screenSize.aspectRatio * 7,
                                fontWeight: FontWeight.bold),),),
                          Text("- 03/2022 to 09/2022 ",style: GoogleFonts.montserrat(
                            textStyle: TextStyle(
                                color: Colors.black,
                                fontSize: _screenSize.aspectRatio * 7,
                                ),),),
                        ],
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.only(
                          right: _screenSize.width/50,
                          left: _screenSize.width / 50,
                          top: _screenSize.height / 50),
                      child: Text(
                        "Worked Specifically as a Front-End Developer using Flutter \nin Android Studio.",
                        style: GoogleFonts.montserrat(
                            textStyle: TextStyle(
                                color: Colors.black,
                                fontSize: _screenSize.aspectRatio * 6,
                                ),
                      ),
                    ),
                    ),
                    Container(
                      margin: EdgeInsets.only(
                          right: _screenSize.width/50,
                          left: _screenSize.width / 50,
                          top: _screenSize.height / 150),
                      child: Text(
                        "Assisted with creating cross platform web components and \nbuild responsive applications using front end frameworks.",
                        style: GoogleFonts.montserrat(
                          textStyle: TextStyle(
                            color: Colors.black,
                            fontSize: _screenSize.aspectRatio * 6,
                          ),
                        ),
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.only(
                          right: _screenSize.width/50,
                          left: _screenSize.width / 50,
                          top: _screenSize.height / 150),
                      child: Text(
                        "Work with senior developer to manage medium, complex design\nprojects for corporate clients.",
                        style: GoogleFonts.montserrat(
                          textStyle: TextStyle(
                            color: Colors.black,
                            fontSize: _screenSize.aspectRatio * 6,
                          ),
                        ),
                      ),
                    ),
                    Row(
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Align(
                              alignment: Alignment.topLeft,
                              child: Container(
                                  margin: EdgeInsets.only(
                                      top: _screenSize.height / 30,
                                      left: _screenSize.width / 150),
                                  width: _screenSize.width / 6,
                                  height: _screenSize.height / 25,
                                  decoration: BoxDecoration(
                                    borderRadius:
                                    BorderRadius.only(topRight: Radius.circular(45)),
                                    color: Color(0xff000000),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Colors.grey.withOpacity(1),
                                        spreadRadius: 5,
                                        blurRadius: 7,
                                        offset: Offset(0, 3), // changes position of shadow
                                      ),
                                    ],
                                  ),
                                  child: Align(
                                    alignment: Alignment.centerLeft,
                                    child: Container(
                                        width: _screenSize.width / 6.1,
                                        height: _screenSize.height / 25,
                                        decoration: BoxDecoration(
                                          borderRadius: BorderRadius.only(
                                            topRight: Radius.circular(50),
                                          ),
                                          color: Color(0xfffbc252),
                                        ),
                                        child: Align(
                                          alignment: Alignment.center,
                                          child: Text(
                                            "Languages",
                                            style: GoogleFonts.montserrat(
                                              textStyle: TextStyle(
                                                  color: Colors.black,
                                                  fontSize: _screenSize.aspectRatio * 6,
                                                  fontWeight: FontWeight.bold),),
                                          ),
                                        )),
                                  )),
                            ),
                            Container(
                              margin: EdgeInsets.only(
                                  right: _screenSize.width/50,
                                  left: _screenSize.width / 50,
                                  top: _screenSize.height / 30),
                              child: Text(
                                "English",
                                style: GoogleFonts.montserrat(
                                  textStyle: TextStyle(
                                    color: Colors.black,
                                    fontSize: _screenSize.aspectRatio * 7,
                                    fontWeight: FontWeight.bold
                                  ),
                                ),
                              ),
                            ),
                            Container(
                              margin: EdgeInsets.only(
                                  right: _screenSize.width/50,
                                  left: _screenSize.width / 50,
                                  top: _screenSize.height / 150),
                              child: Text(
                                "Sinhala",
                                style: GoogleFonts.montserrat(
                                  textStyle: TextStyle(
                                    color: Colors.black,
                                    fontSize: _screenSize.aspectRatio * 7,
                                      fontWeight: FontWeight.bold
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Align(
                              alignment: Alignment.topLeft,
                              child: Container(
                                  margin: EdgeInsets.only(
                                      top: _screenSize.height / 30,
                                      left: _screenSize.width / 150),
                                  width: _screenSize.width / 6,
                                  height: _screenSize.height / 25,
                                  decoration: BoxDecoration(
                                    borderRadius:
                                    BorderRadius.only(topRight: Radius.circular(45)),
                                    color: Color(0xff000000),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Colors.grey.withOpacity(1),
                                        spreadRadius: 5,
                                        blurRadius: 7,
                                        offset: Offset(0, 3), // changes position of shadow
                                      ),
                                    ],
                                  ),
                                  child: Align(
                                    alignment: Alignment.centerLeft,
                                    child: Container(
                                        width: _screenSize.width / 6.1,
                                        height: _screenSize.height / 25,
                                        decoration: BoxDecoration(
                                          borderRadius: BorderRadius.only(
                                            topRight: Radius.circular(50),
                                          ),
                                          color: Color(0xfffbc252),
                                        ),
                                        child: Align(
                                          alignment: Alignment.center,
                                          child: Text(
                                            "MY HOBBIES",
                                            style: GoogleFonts.montserrat(
                                              textStyle: TextStyle(
                                                  color: Colors.black,
                                                  fontSize: _screenSize.aspectRatio * 6,
                                                  fontWeight: FontWeight.bold),),
                                          ),
                                        )),
                                  )),
                            ),
                            Row(
                              children: [
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Container(
                                      margin: EdgeInsets.only(
                                          right: _screenSize.width/50,
                                          left: _screenSize.width / 50,
                                          top: _screenSize.height / 30),
                                      child: Text(
                                        "Sketching",
                                        style: GoogleFonts.montserrat(
                                          textStyle: TextStyle(
                                              color: Colors.black,
                                              fontSize: _screenSize.aspectRatio * 7,
                                              fontWeight: FontWeight.bold
                                          ),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      margin: EdgeInsets.only(
                                          right: _screenSize.width/50,
                                          left: _screenSize.width / 50,
                                          top: _screenSize.height / 150),
                                      child: Text(
                                        "Movies",
                                        style: GoogleFonts.montserrat(
                                          textStyle: TextStyle(
                                              color: Colors.black,
                                              fontSize: _screenSize.aspectRatio * 7,
                                              fontWeight: FontWeight.bold
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Container(
                                      margin: EdgeInsets.only(
                                          right: _screenSize.width/50,
                                          left: _screenSize.width / 80,
                                          top: _screenSize.height / 30),
                                      child: Text(
                                        "Travel",
                                        style: GoogleFonts.montserrat(
                                          textStyle: TextStyle(
                                              color: Colors.black,
                                              fontSize: _screenSize.aspectRatio * 7,
                                              fontWeight: FontWeight.bold
                                          ),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      margin: EdgeInsets.only(
                                          right: _screenSize.width/50,
                                          left: _screenSize.width / 80,
                                          top: _screenSize.height / 150),
                                      child: Text(
                                        "Music",
                                        style: GoogleFonts.montserrat(
                                          textStyle: TextStyle(
                                              color: Colors.black,
                                              fontSize: _screenSize.aspectRatio * 7,
                                              fontWeight: FontWeight.bold
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            )
                          ],
                        ),
                      ],
                    )
                  ],
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
